import { useEffect, useState } from 'react';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css';

import { useNavigate } from 'react-router-dom';
import { Link } from 'react-router-dom';
import '../src/app.css'
import { Modal, Button } from 'react-bootstrap';


function App() {
    const [users,setusers] =useState([]);
    const [user,setuser] =useState( {isChecked: false,id : 0, username: "", status:"Not Started", due_date:"", priority:"Low", description:""});
    const [searchText, setsearchText] = useState("");
    const [username, setusername] = useState("");
    const navigate = useNavigate();
    const [isBackdropOpen, setIsBackdropOpen] = useState(false);
    const [showModal, setShowModal] = useState(false);
    const [selectedUserId, setSelectedUserId] = useState(null);    

    useEffect(()=>{
        GetAll();
        var usernameFromSession = sessionStorage.getItem("username")
        setusername(usernameFromSession);
    }, [])
   
    const GetAll=()=>
    {
        var helper = new XMLHttpRequest();
        helper.onreadystatechange = ()=>{
            if(helper.readyState === 4 && helper.status === 200)
            {
                var allUsersFromServer = 
                    JSON.parse(helper.responseText);
                setusers(allUsersFromServer);
            }
        };
        helper.open("GET", "http://127.0.0.1:9897/users");
        helper.send();
    }


    const OnTextChanged =(args)=>
    {
        //this.state.user represents user to be added in the database
        //here we need to update this.state.user with values from 
        //textboxes ..so we will use this.setState

        var copyOfUser = {...user};
        copyOfUser[args.target.name] = args.target.value;
        setuser(copyOfUser);
    }


    const ClearBoxes=()=>
    {
        setuser({isChecked: false,id : 0, username: "", status:"Not Started", due_date:"", priority:"Low", description:""});
    }

    const RemoveRecord=(id)=>
    {
        console.log(id);
        //XHR Call for Delete Record
        // console.log(`${No} is getting deleted..`)
        var helper = new XMLHttpRequest();
        helper.onreadystatechange = ()=>{
            if(helper.readyState === 4 && helper.status === 200)
            {
                var result =JSON.parse(helper.responseText);
                if(result.affectedRows!==undefined && 
                    result.affectedRows > 0)
                    {
                       GetAll();
                    }

            }
        };
        helper.open("DELETE", "http://127.0.0.1:9897/users/" + id);
        helper.send();
    }

    const EditRecord=(user)=>
    {
      navigate(`/edit-task/${user.id}`, { state: { user } });
    }

    const OnSearch = (args)=>
    {
        setsearchText(args.target.value);
    }
        
    //Popup for new task
    const handleButtonClick = () => 
    {
        ClearBoxes();
        setIsBackdropOpen(true);
    };
    
      const handleCloseBackdrop = () => 
    {
        AddRecord();
        setIsBackdropOpen(false);
    };
    
    //popup delete task
    const handleCloseBackdrop1 = () => 
        {
            
            setIsBackdropOpen(false);
        };

        //delete 
        const handleDelete = () => {
            if (selectedUserId) {
              RemoveRecord(selectedUserId);
              setShowModal(false);
            }
          };

        
  const handleShowModal = (id) => {
    setSelectedUserId(id);
    setShowModal(true);
  };



    const AddRecord=()=>{
        //console.log(this.state.user);
        //XHR POST Code here..
        var helper = new XMLHttpRequest();
        helper.onreadystatechange = ()=>{
            if(helper.readyState === 4 && helper.status === 200)
            {
                var result =JSON.parse(helper.responseText);
                if(result.affectedRows!==undefined && 
                    result.affectedRows > 0)
                    {
                        GetAll();
                        handleCloseBackdrop1();
                    }
            }
        };
        helper.open("POST", "http://127.0.0.1:9897/users");

        helper.setRequestHeader("Content-Type","application/json");
        var userInStringFormat = JSON.stringify(user)
        helper.send(userInStringFormat);
    }


    
     return (
         <div className='container'>
           <div className='inner-container'>
            <div className='div'>
                <h1>Tasks</h1>
                <p>All Tasks</p>
            </div>

            {/* //New Task div */}
            <div>
                <table>
                    <tr className="app">
                    <td>
                    <button className="btn btn-search" onClick={handleButtonClick}>New Task</button>
                    {isBackdropOpen && (
            <div className="backdrop">
               <div className="message-box">
                
               <div className='container'>
           <div>
            <center><h3>New Task</h3></center>
            </div>
            <div className='table-responsive'>
                            <div class="row">
                                <div class="col">
                                      Id:
                                      <input type="text" class="form-control" value={user.id} name='id'/> 
                                </div>
                                <div class="col">
                                     <label for="disabledSelect"> Assigned To:</label>
                                     <input type="text" class="form-control" value={user.username} name='username' onChange={OnTextChanged}/>
                                 </div>
                             </div>
                             <br/>

                            <div class="row">
                                 <div class="col">
                                       Status:
                                       <select class='form-control' type="text" value={user.status} name='status' onChange={OnTextChanged}>
                                            <option value="Not Started">Not Started</option>
                                            <option value="In Progress">In Progress</option>
                                            <option value="Completed">Completed</option>
                                       </select>                  
                                 </div>
                            </div>

                             <br/>
                             <div class="row">
                                    <div class="col">
                                         Due Date:
                                             <input type="date" value={user.due_date} name='due_date' onChange={OnTextChanged}/>
                                    </div>
                                    <div class="col">
                                          <label for="disabledSelect"> Priority:</label>
                                          <select type="text" value={user.priority} name='priority' onChange={OnTextChanged}>
                                                  <option value="Low">Low</option>
                                                  <option value="Normal">Normal</option>
                                                  <option value="High">High</option>
                                          </select>                   
                                     </div>
                              </div>
                              <br/>
                              <div class="row">
                                      <div class="form-group">
                                          <label for="exampleFormControlTextarea1">Description: </label>
                                          <input class="form-control" type="textarea" value={user.description} name='description' onChange={OnTextChanged}/>
                                      </div>
                              </div>
                        
                    </div>
                 </div>
                 <button className='add' onClick={handleCloseBackdrop}>Save</button>
                 {" "}
                 <button className='color' onClick={handleCloseBackdrop1}>Close</button>
                 {" "}
                 <button className='add' onClick={ClearBoxes}>Clear</button>
                </div>
            </div>
                     )}
                     {/* //page Refershand search bar */}
                    <Link  to="/" className="btn btn-search"> Refersh</Link>     
                    </td>
                    </tr>
                    <tr>
                        <td></td>
                    </tr>
                    <tr>
                    <td>
                    <div>
                          <input className='search' type='text' placeholder='search..' value={searchText}
                         onChange={OnSearch}/>
                     </div> 
                     </td>
                    </tr>
                </table>
           </div>
            </div>
                    {/* //Data get in table formate */}
                    <table className='table table-bordered'>
                    <thead>
                             <tr>
                                <td><input type='checkbox'/> </td>
                                 <th>Id</th>
                                 <th>Assigned To</th>
                                 <th>Status</th>
                                 <th>Due Date</th>
                                 <th>Priority</th>
                                 <th>Comments</th>
                                 <th><center>Action</center></th>
                             </tr>
                         </thead>
                        <tbody>
                            {
                                users.map(user=>{
                                 if(searchText!=="")
                                 {
                                    if(user.username.toLowerCase().includes(searchText.toLowerCase()))
                                    {
                                      return <tr key={user.id}>
                                                      <td> <input type="checkbox"checked={user.isChecked}onChange={OnTextChanged}/> </td>
                                                      <td>{user.id}</td>
                                                      <td>{user.username}</td>
                                                      <td>{user.status}</td> 
                                                      <td>{user.due_date}</td> 
                                                      <td>{user.priority}</td> 
                                                      <td>{user.description}</td> 
                                                      <td>
                                                          
                                                      <div className="bt">
            <div className="action">
              <button
                className="btn btn-danger"
                onClick={() => handleShowModal(user.id)}
              >
                Delete
              </button>
            </div>
         

                                                                <div className='action'>
                                                                <button className='btn btn-info'onClick={
                                                                                      ()=>
                                                                                      {
                                                                                      EditRecord(user)
                                                                                      }}> Edit
                                                              </button>
                                                              </div>
                                                              </div>
                                                         </td>
                                             </tr>
                                    }
                                    else
                                    {
                                        return null;
                                    }
                                }
                                else
                                {
                                    return <tr key={user.id}>
                                        
                                                     <td> <input type="checkbox"checked={user.isChecked}onChange={OnTextChanged}/></td>
                                                    <td>{user.id}</td>
                                                      <td>{user.username}</td>
                                                      <td>{user.status}</td> 
                                                      <td>{user.due_date}</td> 
                                                      <td>{user.priority}</td> 
                                                      <td>{user.description}</td> 
                                                      <td>
                                                            {"                "}
                                                         
                                                            <div className="bt">
            <div className="action">
              <button
                className="btn btn-danger"
                onClick={() => handleShowModal(user.id)}
              >
                Delete
              </button>
            </div>
            <div className='action'>
                                                                 <button className='btn btn-info' onClick={
                                                                                                ()=>
                                                                                                 {
                                                                                                  EditRecord(user)
                                                                                                  } }>Edit
                                                                 </button>
                                                                
                                                            </div>
                                                                 </div>
                                                        </td>
                                           </tr>
                                           
                                 }
                                })
                            }
                        </tbody>
                    </table>
                    <Modal show={showModal} onHide={() => setShowModal(false)}>
        <Modal.Header closeButton>
          <Modal.Title>Confirm Deletion</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          Are you sure you want to delete the record with ID: {selectedUserId}?
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowModal(false)}>
            Cancel
          </Button>
          <Button variant="danger" onClick={handleDelete}>
            Delete
          </Button>
        </Modal.Footer>
      </Modal>
                    <div className='fotter'>
                        <button>First</button>
                        <button>Prev</button>
                        <button>1</button>
                        <button>Next</button>
                        <button>Last</button>
                    </div>
                  <br/>
                    
                 </div>
            );
}
 
export default App;
import { useEffect, useState } from 'react';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css';
import { useParams,useLocation, useNavigate } from 'react-router-dom';

function EditTask() {
    const { id } = useParams();
    const [users,setusers] =useState([]);
    const [user1,setuser] =useState( {id : 0, username: "", status:"", due_date:"", priority:"", description:""});
    const [message,setmessage] =useState("");
    const [searchText, setsearchText] = useState("");
    const [username, setusername] = useState("");
      const location = useLocation();
      const navigate = useNavigate();
      const { user } = location.state;
    
      const [updatedItem, setUpdatedItem] = useState({ ...user });
    

    const OnTextChanged =(args)=>{
        //this.state.user represents user to be added in the database
        //here we need to update this.state.user with values from 
        //textboxes ..so we will use this.setState

        var copyOfUser = {...user};
        copyOfUser[args.target.name] = args.target.value;
       setUpdatedItem(copyOfUser);

    }

    const SetMessage=(messageToBeSet)=>{
         setmessage(messageToBeSet);
         setTimeout(() => {
                             setmessage("");
                        }, 5000);
    }


    const ClearBoxes=()=>{
        setuser({id : 0, username: "", status:"", due_date:"", priority:"", description:""});
}


    const EditRecord=(id)=>{
        //console.log(`${No} is getting edited.`);
        var userToEdit = null;
        for(var i=0;i<users.length; i++)
        {
            var currentUser = users[i];
            if(currentUser.id === id)
            {
                userToEdit = {...currentUser};
                break;
            }
        }

        if(userToEdit!==null)
        {
            setuser(userToEdit);
            SetMessage("Found Record!")
        }
        else
        {
            SetMessage("No Record Found !")
        }
    }

    const UpdateRecord=()=>{
        //console.log(this.state.user);
        //XHR POST Code here..
        var helper = new XMLHttpRequest();
        helper.onreadystatechange = ()=>{
            if(helper.readyState === 4 && helper.status === 200)
            {
                var result =JSON.parse(helper.responseText);
                if(result.affectedRows!==undefined && 
                    result.affectedRows > 0)
                    {
                        SetMessage("Record updated.");
                        
                        navigate('/');
                       
                    }
                    else
                    {
                        SetMessage("Some problem!.");
                    }
            }
        };
        helper.open("PUT", 
                "http://127.0.0.1:9897/users/" + updatedItem.id);

        helper.setRequestHeader("Content-Type","application/json");
        var userInStringFormat = JSON.stringify(updatedItem)
        helper.send(userInStringFormat);
    }


    const OnSearch = (args)=>{
        setsearchText(args.target.value);
    }

     return (
     <div className='container'>
         <div>
            <center><h3>New Task</h3></center>
        </div>
                         <div className='table-responsive'>
                             <div class="row">
                    <div class="col">
                        Id:
                        <input type="text" class="form-control" value={updatedItem.id} name='id' onChange={OnTextChanged}/> 
                    </div>
                    <div class="col">
                        <label for="disabledSelect"> Assigned To:</label>
                        <input type="text" class="form-control" value={updatedItem.username} name='username' onChange={OnTextChanged}/>
                    </div>
                </div>
                <br/>

                <div class="row">
                    <div class="col">
                        Status:
                        <select class='form-control' type="text" value={updatedItem.status} name='status' onChange={OnTextChanged}>
                             <option value="Not Started">Not Started</option>
                             <option value="In Progress">In Progress</option>
                            <option value="Completed">Completed</option>
                        </select>                  
                    </div>
                </div>

                <br/>
                <div class="row">
                        <div class="col">
                        Due Date:
                        <input type="date" value={updatedItem.due_date} name='due_date' onChange={OnTextChanged}/>
                       </div>
                       <div class="col">
                       <label for="disabledSelect"> Priority:</label>
                          <select type="text" value={user.priority} name='priority' onChange={OnTextChanged}>
                            <option value="Low">Low</option>
                            <option value="Normal">Normal</option>
                            <option value="High">High</option>
                          </select>                   
                     </div>
                </div>
                <br/>
                <div class="row">
                <div class="form-group">
                <label for="exampleFormControlTextarea1">Description: </label>
                <input class="form-control" type="textarea" value={updatedItem.description} name='description' onChange={OnTextChanged}/>
                </div>
                </div>
                <div>
                <center>
                                          <button className='btn btn-info' onClick={ClearBoxes}>Clear</button>
                                           {"  "}
                                          <button className='btn btn-success' onClick={UpdateRecord}>Update Record</button>
                </center>    
                <br/>    
                </div>
                     </div>
                    <center>
                       <div className='alert alert-success' 
                            style={{color: "black"}}>
                             {message}
                       </div>
                    </center>
                 </div>);
}
 
export default EditTask;
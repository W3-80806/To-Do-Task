import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import EditTask from './EditTask';
import App from './App';


const Landing = () => {
  return (
    
      <Router>
        <Routes>
          <Route path="/" element={<App/>} />
          <Route path="/edit-task/:id" element={<EditTask />} />
        </Routes>
      </Router>
    
  );
};

export default Landing;
